import supervisor
import usb_hid
import usb_midi

supervisor.set_usb_identification(manufacturer="MorseOSLAB", product="VBAND RP2040")
usb_midi.disable()
usb_hid.enable((usb_hid.Device.KEYBOARD,))
