"""VBAND on Waveshare RP2040-Zero: GP5 left, GP4 right, active low."""
import board
import digitalio
import neopixel_write
import supervisor
import time
import usb_hid

keyboard = next(device for device in usb_hid.devices
                if device.usage_page == 1 and device.usage == 6)
contacts = [digitalio.DigitalInOut(pin) for pin in (board.GP5, board.GP4)]
for contact in contacts:
    contact.switch_to_input(pull=digitalio.Pull.UP)

candidate = [False, False]
stable = [False, False]
changed = [0, 0]
report = bytearray(8)
last = None
pixel = digitalio.DigitalInOut(board.GP16)
pixel.switch_to_output(value=False)
off = bytes((0, 0, 0))
amber = bytes((1, 1, 0))
green = bytes((1, 0, 0))
paddle_colors = {
    0x01: bytes((0, 0, 1)),
    0x10: bytes((0, 1, 0)),
    0x11: bytes((0, 1, 1)),
}
blink_interval_ns = 250_000_000
blink_duration_ns = 15_000_000
color = None

while True:
    now = time.monotonic_ns()
    for index, contact in enumerate(contacts):
        closed = not contact.value
        if closed != candidate[index]:
            candidate[index] = closed
            changed[index] = now
        if now - changed[index] >= 2_000_000:
            stable[index] = candidate[index]

    mask = (0x01 if stable[0] else 0) | (0x10 if stable[1] else 0)
    if not supervisor.runtime.usb_connected:
        last = None
    elif mask != last:
        report[0] = mask
        try:
            keyboard.send_report(report)
        except OSError:
            # USB is not ready. Retry with the current contact state.
            time.sleep(0.005)
        else:
            last = mask

    if mask:
        next_color = paddle_colors[mask]
    elif now % blink_interval_ns < blink_duration_ns:
        next_color = green if last is not None else amber
    else:
        next_color = off
    if next_color != color:
        neopixel_write.neopixel_write(pixel, next_color)
        color = next_color
